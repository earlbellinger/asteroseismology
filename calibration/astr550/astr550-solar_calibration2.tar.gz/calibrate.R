#### Calibrate a solar model by matching log L, log R, Fe/H and log age 
#### Author: Earl Bellinger ( bellinger@mps.mpg.de ) 
#### Stellar Ages & Galactic Evolution Group 
#### Max-Planck-Institut fur Sonnensystemforschung 
#### Department of Astronomy, Yale University 

### CONSTANTS 
log10_Z_div_X_solar = log10(0.02293) # Grevesse & Sauval 1998 
constraint_names = c("log L", "log R", "Fe/H", "log Age") 
solar_age = 4.572 * 10**9

### SPECIFY LOCATION FOR CALCULATION RESULT 
directory <- "result" 
cat(paste("Outputting results in directory:", directory, "\n")) 

### INITIALIZE PARAMETERS FOR SEARCH 
param_names <- c("Y_0", "Z_0", "alpha") 
param_init <- c(0.2712, 0.0184, 1.8472) 

### DEFINE OBJECTIVE FUNCTION 
objective <- function() { 
    ## minimize log(model value / solar value)**2 for all values needed to match
    # searches in LOGS_MS subdirectory of the global directory variable 
    
    hstry <- read.table(file.path(directory, 'LOGS_MS', 'history.data'), 
        header=1, skip=5)
    mdl <- hstry[nrow(hstry),]
    
    mdl_Fe_H <- mdl$log_surf_cell_z-log10(mdl$surface_h1)-log10_Z_div_X_solar
    mdl_vals <- c(mdl$log_L, mdl$log_R, mdl_Fe_H, log10(mdl$star_age/solar_age))
    
    objectives <- mdl_vals**2
    
    cat("*** Model values and objective values\n")
    cat(paste(constraint_names, mdl_vals, objectives, "\n"))
    
    sum(objectives)
}

### SEARCH
precision <<- 4 # number of decimal places considered 
abstol <<- 10**-5 # stop if the objective is lower than this amount 
reltol <<- 10**-8 # stop if the objective variation is lower than this amount 
iteration <<- 0 
ran <<- 0 
best_val <<- Inf 
best_param <<- param_init 

run <- function(params) {
    ## dispatch a stellar evolutionary track with the input parameters 
    # must be list with Y_0, Z_0, and alpha in that order 
    
    params <- round(params, precision) # truncate precision of search 
    cat("\n* Trying parameters:\n")
    cat(paste(param_names, params, "\n"))
    
    Y_0 <- params[1]
    Z_0 <- params[2]
    alpha <- params[3]
    
    iteration <<- iteration + 1
    cat(paste("** iter:", iteration, "\n"))
    
    if (Y_0 < 0.2463 || Y_0 > 0.35  || 
        Z_0 < 0.01   || Z_0 > 0.03 || 
        alpha < 1.5  || alpha > 2.5) {
        
        cat("Input parameters out of bounds; skipping\n")
        return(Inf)
    }
    
    ran <<- ran + 1 
    cat(paste("**  ran:", ran, "\n"))
    
    command <- paste("./dispatch.sh", 
        '-Y', Y_0, 
        '-Z', Z_0, 
        '-a', alpha, 
        '-d', directory)
    print(command)
    system(command)
    
    obj_val <- objective()
    cat(paste("**** objective value =", obj_val, "\n"))
    
    if (obj_val < best_val) {
        best_val <<- obj_val
        cat(paste("*****", param_names, params, "\n"))
        best_param <<- params
        cat("***** New record! \n")
    }
    
    obj_val
}

cat("Initializing optimization for solar parameters \n")

result <- optim(par=param_init, fn=run, 
    control=list(trace=999, abstol=abstol, reltol=reltol))

print(result)

